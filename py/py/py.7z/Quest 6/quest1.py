﻿di = {}
with open("recepts.txt", "r") as file:
  read = file.readlines()
  print(read)
    