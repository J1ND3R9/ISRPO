﻿import requests
from bs4 import BeautifulSoup

def print_news(news):
  for key, li in news.items():
    print("Заголовок: " + li[0] + "\nВремя: " + li[1] + "Ссылка")
url = 'https://lenta.ru/'
# Отправка GET-запроса к указанному URL
response = requests.get(url)

# Проверка успешности запроса
if response.status_code == 200:
  allNews = []
  news = {}
  soup = BeautifulSoup(response.content, 'html.parser')
  allNews = soup.findAll('a', class_='card-mini _topnews', href=True)
  for data in allNews:
    if data.find('h3') is not None:
      l = []
      l.append(data.find('h3').text)
      l.append(data.find('time').text)
      href_wurl = url + data['href']
      news[href_wurl] = l
  print(news)
else:
    print(f"Failed to retrieve the page. Status code: {response.status_code}")
